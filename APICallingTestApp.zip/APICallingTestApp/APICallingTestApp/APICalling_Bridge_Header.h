//
//  APICalling_Bridge_Header.h
//  APICallingTestApp
//
//  Created by iMac2 on 02/02/23.
//

#ifndef APICalling_Bridge_Header_h
#define APICalling_Bridge_Header_h


#import "AllAPICalls.h" 

#endif /* APICalling_Bridge_Header_h */
