//
//  WebServiceHandler.swift
//  APICallingTestApp
//
//  Created by iMac2 on 02/02/23.
//

import UIKit

import SystemConfiguration
import Alamofire



class WebServiceHandler: NSObject {
    
    //Staging
//    let basePath = "http://boxonsaassestage.smarteweb.com/"
    
    // Development
    let basePath = "http://boxonsaasdev.inviewpro.com/"

    func requestWithUrlString(_ urlString:NSString,method:NSString,params:NSDictionary) -> (NSMutableURLRequest) {
        
        if(method .isEqual(to: "GET")) {
            let urlStr:NSString = urlString.appending(self.convertParams(params) as String) as NSString
            let request = NSMutableURLRequest(url: URL(string: urlStr as String)! as URL)
            return request
        }
        else {
            let request = NSMutableURLRequest(url: URL(string: urlString as String)! as URL)
            request.httpMethod = method as String
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            
            let parameter: NSDictionary = params
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: parameter, options: .prettyPrinted)
            } catch {
                //handle error. Probably return or mark function as throws
                print(error)
                
            }
            return request
        }
    }
    func convertParams(_ parameters:NSDictionary) -> (NSString) {
        let keys: [NSString] =  parameters.allKeys as! [NSString]
        
        var paramtersString: String = ""
        
        //        var key:NSString
        for key in keys {
            
            if(paramtersString.count == 0) {
                paramtersString = paramtersString.appendingFormat("?%@=%@&",key.addingPercentEscapes(using: String.Encoding.utf8.rawValue)!,(parameters[key]! as AnyObject).addingPercentEscapes(using: String.Encoding.utf8.rawValue)!)
            }
            else {
                paramtersString = paramtersString.appendingFormat("%@=%@&",key.addingPercentEscapes(using: String.Encoding.utf8.rawValue)!,(parameters[key]! as AnyObject).addingPercentEscapes(using: String.Encoding.utf8.rawValue)!)
            }
            
        }
        
        if paramtersString.count > 0 {
            paramtersString = (paramtersString as NSString).substring(to: paramtersString.count - 1)
            //
        }
        
        return paramtersString as (NSString)
    }
    
    func testAPI(_ apiName: NSString!,
                 parms: AnyObject,
                 completion: @escaping (_ result: Any) -> Void,
                 failure: (_ err:NSError) -> Void )
    {
        let appendBaseURL = "\(basePath)\(apiName!)"
        print("After Apending Base URL \(appendBaseURL)")

        let url = URL(string: appendBaseURL as String)!
        let resultString = NSMutableString()
        
        for item in parms.allKeys {
            if resultString.length>0 {
                resultString.append("&")
                
            }
            let bookName = parms[item] as AnyObject
            resultString.appendFormat("\(item)=\(bookName)" as NSString)
            // print(" test data \(resultString)")
        }
        
        let finalurl = "\(url)?" + "\(resultString)"
        print(" finalurl ==>  \(finalurl)")
        // let paramertsValues = self.convertParams(parms as! NSDictionary)
        //   let request1 =  self .requestWithUrlString(urlStr as NSString, method: "GET", params: parms as! NSDictionary)
        
        Alamofire.request(finalurl, method: .get, parameters: nil, encoding: JSONEncoding.default)
            .downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
              //  print("Progress: \(progress.fractionCompleted)")
            }
            .validate { request, response, data in
                // Custom evaluation closure now includes data (allows you to parse data to dig out error messages if necessary)
                return .success
            }
            .responseJSON { response in
                switch(response.result) {
                case .success(_):
                    if response.result.value != nil{
                        //print(response.result.value!)
                        let responseDict = response.result.value as! NSDictionary
                        completion(responseDict)
                    }
                    break
                case .failure(_):
                    print(response.result.error!)
                    if LoadingOverlay.shared.isLoading == true {
                        LoadingOverlay.shared.hideOverlayView()
                    }
            //    Helper.sharedInstance.makeAlertCall(msg: "Something went wrong with server")
                    
                    break
                }
        }
    }
    
    func sendRequestToApi3(apiName: NSString!,
                           parms: AnyObject,
                           completion: @escaping (_ result: Any) -> Void,
                           failure: (_ err:NSError) -> Void ) {
        let appendBaseURL = "\(basePath)\(apiName!)"
        print("After Apending Base URL \(appendBaseURL)")
        
        let url = URL(string: appendBaseURL as String)!
        let urlRequest = URLRequest(url: url)
        let encodedURLRequest = try! URLEncoding.queryString.encode(urlRequest, with: parms as? Parameters)
        print("encodedURLRequest : ===> \(encodedURLRequest)")

        if isInternetAvailable() {
            Alamofire.request(encodedURLRequest)
                .validate { request, response, data in
                    return .success
                }
                .responseJSON { response in
                    switch(response.result) {
                    case .success(_):
                        if response.result.value != nil{
                           // print(response.result.value!)
                            let responseDict = response.result.value as! NSDictionary
                            completion(responseDict)
                        }
                        break
                    case .failure(_):
                        print(response.result.error as Any)
                        
                        if LoadingOverlay.shared.isLoading == true {
                            LoadingOverlay.shared.hideOverlayView()
                        }
         //   Helper.sharedInstance.makeAlertCall(msg: "Something went wrong with server")
                    
                        break
                    }
            }
        }
        else {
            print("**** No Internet connection ****")
            DispatchQueue.main.async {
                self.showAlert("No Internet Connection", msg: "Make sure your device is connected to the internet.")
            }
        }
    }
    
    func sendRequestToApi3StringResponse(apiName: NSString!,
                           parms: AnyObject,
                           completion: @escaping (_ result: Any) -> Void,
                           failure: (_ err:NSError) -> Void ) {
        let appendBaseURL = "\(basePath)\(apiName!)"
        print("After Apending Base URL \(appendBaseURL)")
        
        let url = URL(string: appendBaseURL as String)!
        let urlRequest = URLRequest(url: url)
        let encodedURLRequest = try! URLEncoding.queryString.encode(urlRequest, with: parms as? Parameters)
        print("encodedURLRequest : ===> \(encodedURLRequest)")

        if isInternetAvailable() {
            Alamofire.request(encodedURLRequest)
                .validate { request, response, data in
                    return .success
                }
                .responseJSON { response in
                    switch(response.result) {
                    case .success(_):
                        if response.result.value != nil{
                           // print(response.result.value!)
                            let responseDict = response.result.value as! String
                            completion(responseDict)
                        }
                        break
                    case .failure(_):
                        print(response.result.error as Any)
                        
                        if LoadingOverlay.shared.isLoading == true {
                            LoadingOverlay.shared.hideOverlayView()
                        }
         //   Helper.sharedInstance.makeAlertCall(msg: "Something went wrong with server")
                    
                        break
                    }
            }
        }
        else {
            print("**** No Internet connection ****")
            DispatchQueue.main.async {
                self.showAlert("No Internet Connection", msg: "Make sure your device is connected to the internet.")
            }
        }
    }
    
    func sendRequestToApi3NSArray(apiName: NSString!,
                           parms: AnyObject,
                           completion: @escaping (_ result: Any) -> Void,
                           failure: (_ err:NSError) -> Void ) {
        let appendBaseURL = "\(basePath)\(apiName!)"
        print("After Apending Base URL \(appendBaseURL)")
        
        let url = URL(string: appendBaseURL as String)!
        let urlRequest = URLRequest(url: url)
        let encodedURLRequest = try! URLEncoding.queryString.encode(urlRequest, with: parms as? Parameters)
        print("encodedURLRequest : ===> \(encodedURLRequest)")

        if isInternetAvailable() {
            Alamofire.request(encodedURLRequest)
                .validate { request, response, data in
                    return .success
                }
                .responseJSON { response in
                    switch(response.result) {
                    case .success(_):
                        if response.result.value != nil{
                           // print(response.result.value!)
                            let responseDict = response.result.value as! NSArray
                            completion(responseDict)
                        }
                        break
                    case .failure(_):
                        print(response.result.error as Any)
                        
                        if LoadingOverlay.shared.isLoading == true {
                            LoadingOverlay.shared.hideOverlayView()
                        }
         //   Helper.sharedInstance.makeAlertCall(msg: "Something went wrong with server")
                    
                        break
                    }
            }
        }
        else {
            print("**** No Internet connection ****")
            DispatchQueue.main.async {
                self.showAlert("No Internet Connection", msg: "Make sure your device is connected to the internet.")
            }
        }
    }

    func postWebserviceWithURL(_ strUrl: String, param: NSDictionary?, completion: @escaping (_ result: AnyObject) -> Void,
                               failure: (_ err:NSError) -> Void ) -> (){
        let appendBaseURL = "\(basePath)\(strUrl)"
        print("After Apending Base URL \(appendBaseURL)")

        let parameters: Parameters = param as! Parameters

        print("Paramerts in API \(parameters)")
        if isInternetAvailable() {
        Alamofire.request(appendBaseURL, method: .post, parameters: parameters, encoding: JSONEncoding.default)
            .downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
                // print("Progress: \(progress.fractionCompleted)")
            }
            .validate { request, response, data in
                
                return .success
            }

            .responseJSON { response in
                switch response.result {
                  //  print(response.result)
                case .success(let data):
                    let responseDict = data as! NSDictionary
                    completion(responseDict)
                    debugPrint(response)
                    break
                    
                case .failure(let error):
                    if LoadingOverlay.shared.isLoading == true {
                        LoadingOverlay.shared.hideOverlayView()
                    }
                    print("Request failed with error: ==> \(error)")
                    Helper.sharedInstance.makeAlertCall(msg: "Something went wrong with server")
                    break
                  print("Request failed with error: ==> \(error)")
                default:
                    print("Request failed with error: ")
                    
                }
            }
        }
        else
        {
            print("**** No Internet connection ****")
            DispatchQueue.main.async {
                self.showAlert("No Internet Connection", msg: "Make sure your device is connected to the internet.")
          }
       }
    }
    
    func TestpostWebserviceWithURL(_ strUrl: String, param: NSDictionary?, completion: @escaping (_ result: AnyObject) -> Void,
                               failure: (_ err:NSError) -> Void ) -> (){
        
        let appendBaseURL = "\(strUrl)"
        print("After Apending Base URL \(appendBaseURL)")

        let parameters: Parameters = param as! Parameters
        
        if isInternetAvailable() {
            Alamofire.request(appendBaseURL, method: .post, parameters: parameters, encoding: JSONEncoding.default)
                .downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
                    // print("Progress: \(progress.fractionCompleted)")
                }
                .validate { request, response, data in
                    
                    return .success
                }
                .responseJSON { response in
                    switch response.result {
                        
                    case .success(let data):
                        let responseDict = data as! NSDictionary
                        completion(responseDict)
                        //  debugPrint(response)
                        break
                        
                    case .failure(let error):
                        if LoadingOverlay.shared.isLoading == true {
                            LoadingOverlay.shared.hideOverlayView()
                        }
                        Helper.sharedInstance.makeAlertCall(msg: "Something went wrong with server")
                        break
                        print("Request failed with error: ==> \(error)")
                    default:
                        print("Request failed with error: ")
                        
                    }
            }
        }
        else
        {
            print("**** No Internet connection ****")
            DispatchQueue.main.async {
                self.showAlert("No Internet Connection", msg: "Make sure your device is connected to the internet.")
            }
        }
    }
    
    func isInternetAvailable() -> Bool
    {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
    
    func showAlert(_ title:NSString, msg:NSString) {
        
        if LoadingOverlay.shared.isLoading == true {
            LoadingOverlay.shared.hideOverlayView()
        }
        
        let window = UIApplication.shared.keyWindow
        if let topController = window!.visibleViewController() {
            let alert = UIAlertController(title: title as String , message: msg as String, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
            
            topController.present(alert, animated: true, completion: nil)
        }
    }
}
