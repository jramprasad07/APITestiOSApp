//
//  Helper.swift
//  APICallingTestApp
//
//  Created by iMac2 on 02/02/23.
//

import UIKit

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class Helper: NSObject {
    static let sharedInstance = Helper()

  /*  private static var __once: () = {
         Static.instance = Helper()
    }() */

    var alertView = UIAlertController()
    
   /* class var sharedInstance: Helper {
        
        struct Static {
            
            static var onceToken: Int = 0
            static var instance: Helper? = nil
        }
        
        _ = Helper.__once
        
        return Static.instance!
    } */
    
        
    func APIBaseURLDEV() -> (NSString) {
        return Bundle.main.object(forInfoDictionaryKey: "APIBaseURL") as! NSString
    }
    func APIBaseURLLive() -> (NSString) {
        return Bundle.main.object(forInfoDictionaryKey: "APIBaseURLLive") as! NSString
    }
    func APIBaseURLStage() -> (NSString) {
        return Bundle.main.object(forInfoDictionaryKey: "APIBaseURLStage") as! NSString
    }
    
    func getTwillioCallDetailsTimer() -> (Double) {
        let timeInterval = Bundle.main.object(forInfoDictionaryKey: "TwillioCallDetailsTimeInterval") as! NSString
        return timeInterval.doubleValue
    }
    
    func removeNumberFormat(_ mobileNumber:NSString)-> (String) {
        var number = mobileNumber
        number = number .replacingOccurrences(of: "(", with: "") as NSString
        number = number .replacingOccurrences(of: ")", with: "") as NSString
        number = number .replacingOccurrences(of: " ", with: "") as NSString
        number = number .replacingOccurrences(of: "-", with: "") as NSString
        number = number .replacingOccurrences(of: "+", with: "") as NSString
        
        return number as (String)
    }

    
    func makeAlertCall (msg:NSString) {
        let window = UIApplication.shared.keyWindow
        if let topController = window!.visibleViewController() {
            alertView = UIAlertController(title: "Boxon" , message: msg as String, preferredStyle: .alert)
            
            let action = UIAlertAction(title: "OK", style: .default, handler: { (UIAlertAction) -> Void in
                
                self.alertView.dismiss(animated: true, completion: nil)
            })
            alertView.addAction(action)
            topController.present(alertView, animated: true, completion: nil)
        }
    }
    
    func hideGSMAlert () {
        self.alertView.dismiss(animated: true, completion: nil)
    }
    
   
  
    
}

// MARK: - Date

extension Helper {
    
    func getMonth(_ date: Foundation.Date, withComponent monthCount: Int) -> String {
        
        let calendar: Calendar = Calendar.current
        var component: DateComponents = DateComponents()
        component.month = monthCount
        let newDate: Foundation.Date = (calendar as NSCalendar).date(byAdding: component, to: date, options: NSCalendar.Options(rawValue: 0))!
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM"
        
        return dateFormatter.string(from: newDate)
    }
    
    func getConvertedDate (_ date: String, oldFormat: String, newFormat: String) -> String {
        self.isNilOrEmpty(date as NSString)
        print(date)
        if date.count == 0{
            return date
        }
        else{
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = oldFormat
            dateFormatter.timeZone = TimeZone(identifier: "UTC")
            let date = dateFormatter.date(from: date)
            
            dateFormatter.dateFormat = newFormat
           //  dateFormatter.timeZone = NSTimeZone.localTimeZone()
            dateFormatter.timeZone = TimeZone(identifier: "UTC")
            let timeStamp = dateFormatter.string(from: date!)
            
            return timeStamp
        }
    }
    
    func getConvertedDateToUTC (_ date: String, oldFormat: String, newFormat: String) -> String {
        self.isNilOrEmpty(date as NSString)
        print(date)
        if date.count == 0{
            return date
        }
        else{
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = oldFormat
//            dateFormatter.timeZone = NSTimeZone(name: "UTC")
            dateFormatter.timeZone = TimeZone.autoupdatingCurrent
            let date = dateFormatter.date(from: date)
            
            dateFormatter.dateFormat = newFormat
            //  dateFormatter.timeZone = NSTimeZone.localTimeZone()
            dateFormatter.timeZone = TimeZone(identifier: "UTC")
            let timeStamp = dateFormatter.string(from: date!)
            
            return timeStamp
        }
    }
    
    func getConvertedDateToLocalZone (_ date: String, oldFormat: String, newFormat: String) -> String {
        self.isNilOrEmpty(date as NSString)
        print(date)
        if date.count == 0{
            return date
        }
        else{
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = oldFormat
            dateFormatter.timeZone = TimeZone(identifier: "UTC")
            let date = dateFormatter.date(from: date)
            
            dateFormatter.dateFormat = newFormat
            dateFormatter.timeZone = TimeZone.autoupdatingCurrent
            //  dateFormatter.timeZone = NSTimeZone(name: "UTC")
            let timeStamp = dateFormatter.string(from: date!)
            
            return timeStamp
        }
    }
    
    func getConvertLocalDateToLocalZone (_ date: String, oldFormat: String, newFormat: String) -> String {
        self.isNilOrEmpty(date as NSString)
        print(date)
        if date.count == 0{
            return date
        }
        else{
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = oldFormat
            dateFormatter.timeZone = TimeZone.autoupdatingCurrent
//            dateFormatter.timeZone = NSTimeZone(name: "UTC")
            let date = dateFormatter.date(from: date)
            
            dateFormatter.dateFormat = newFormat
            dateFormatter.timeZone = TimeZone.autoupdatingCurrent
            //  dateFormatter.timeZone = NSTimeZone(name: "UTC")
            let timeStamp = dateFormatter.string(from: date!)
            
            return timeStamp
        }
    }
    
    func getDateToLocalZone (_ date: String, oldFormat: String, newFormat: String) -> Foundation.Date {
        self.isNilOrEmpty(date as NSString)
        print(date)
//        if date.characters.count == 0{
//            return date
//        }
//        else{
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = oldFormat
            dateFormatter.timeZone = TimeZone(identifier: "UTC")
            let date = dateFormatter.date(from: date)
            
//            dateFormatter.dateFormat = newFormat
//            dateFormatter.timeZone = NSTimeZone.localTimeZone()
//            //  dateFormatter.timeZone = NSTimeZone(name: "UTC")
//            let timeStamp = dateFormatter.stringFromDate(date!)
        
            return date!
//        }
    }
    
    func TimeZoneAbbrev() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.dateFormat = "ZZZZ"
        let strDate = dateFormatter.string(from: Foundation.Date())
        return strDate
        // return NSTimeZone.localTimeZone().abbreviation!
    }
}

extension Foundation.Date {
    
    func getCurrentDate(_ dateFormat: String) -> String {
        
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        
        return dateFormatter.string(from: self)
    }
    
    func isGreaterThanDate(_ dateToCompare : Foundation.Date) -> Bool {
        
        //Declare Variables
        var isGreater = false
        
        //Compare Values
        if self.compare(dateToCompare) == ComparisonResult.orderedDescending
        {
            isGreater = true
        }
        
        //Return Result
        return isGreater
    }
    
    func isLessThanDate(_ dateToCompare : Foundation.Date) -> Bool {
        
        //Declare Variables
        var isLess = false
        
        //Compare Values
        if self.compare(dateToCompare) == ComparisonResult.orderedAscending {
            isLess = true
        }
        
        //Return Result
        return isLess
    }
    
    func isEqualToCurrentDate(_ dateToCompare : Foundation.Date) -> Bool {
        
        //Declare Variables
        var isEqualTo = false
        
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let currentDate = dateFormatter.string(from: self)
        let comparedDate = dateFormatter.string(from: dateToCompare)
        
        if currentDate == comparedDate {
            isEqualTo = true
        }
        
        //Return Result
        return isEqualTo
    }
    
    func addDays(_ daysToAdd : Int) -> Foundation.Date {
        
        let secondsInDays : TimeInterval = Double(daysToAdd) * 60 * 60 * 24
        let dateWithDaysAdded : Foundation.Date = self.addingTimeInterval(secondsInDays)
        
        //Return Result
        return dateWithDaysAdded
    }
    
    func addHours(_ hoursToAdd : Int) -> Foundation.Date {
        
        let secondsInHours : TimeInterval = Double(hoursToAdd) * 60 * 60
        let dateWithHoursAdded : Foundation.Date = self.addingTimeInterval(secondsInHours)
        
        //Return Result
        return dateWithHoursAdded
    }
    
    func monthsFrom(_ date:Foundation.Date) -> NSInteger{
        return (Calendar.current as NSCalendar).components(.month, from: date, to: self, options: []).month!
    }
    
    func daysFrom(_ date:Foundation.Date) -> Int{
        return (Calendar.current as NSCalendar).components(.day, from: date, to: self, options: []).day!
    }
}

// MARK: - Color

extension UIColor {
    
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(netHex:Int) {
        self.init(red:(netHex >> 16) & 0xff, green:(netHex >> 8) & 0xff, blue:netHex & 0xff)
    }
}
// MARK: - Date
extension Foundation.Date
{
    
    func isdatesame(_ dateToCompare : Foundation.Date) -> Bool
    {
        //Declare Variables
        var isEqualTo = false
        
        //Compare Values
        if self.compare(dateToCompare) == ComparisonResult.orderedSame
        {
            isEqualTo = true
        }
        
        //Return Result
        return isEqualTo
    }
    
    
    
}

// MARK: - String

extension Helper {
    
    func isNilOrEmpty(_ string: NSString?) -> Bool {
        switch string {
        case .some(let nonNilString):
            return nonNilString.length == 0
        default:
            return true
        }
    }
    func noNilString(_ string: NSString?) -> NSString {
        if (string?.length > 0  && (string != ("null"))) {
            return string!
        }
        else{
            return ""
        }
    }
    public class var isIpad:Bool {
        if #available(iOS 8.0, *) {
            return UIScreen.main.traitCollection.userInterfaceIdiom == .pad
        } else {
            return UIDevice.current.userInterfaceIdiom == .pad
        }
    }
    public class var isIphone:Bool {
        if #available(iOS 8.0, *) {
            return UIScreen.main.traitCollection.userInterfaceIdiom == .phone
        } else {
            return UIDevice.current.userInterfaceIdiom == .phone
        }
    }
}

extension String {
    
    func isValidEmailAddress ()-> Bool {
        
        let regex = try! NSRegularExpression(pattern: "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}$", options: [.caseInsensitive])
        return regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0,count)) != nil
    }
    
    func isValidPinCode ()-> Bool {
        
        let regex = try! NSRegularExpression(pattern: "^[0-9]{6}$", options: [.caseInsensitive])
        return regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0,count)) != nil
    }
    
    func isStringValueAvailable()-> String {
        return self
    }
}


extension NSDictionary {
    func isHaveBoolValue(_ key:NSString) -> (Bool) {
        if let value = self[key] as? Bool {
            
          return value
        }
        return false
    }
    
    func isHaveStringValue(_ key:NSString) -> (String) {
        if let value = self[key] as? NSString {
            if (value.length > 0  && (value != ("null"))) {
                return value as (String)
            }
            else{
                return ""
            }
           
        }
        return ""
    }
    
    func isHaveArrayValue(_ key:NSString) -> (NSArray) {
        if let value = self[key] as? NSArray {
            if(value.count > 0) {
                return value
            }
            else {
                return []
            }
        }
        return []
    }
    
    func isHaveMutableArrayValue(_ key:NSString) -> (NSMutableArray) {
        if let value = self[key] as? NSMutableArray {
            if(value.count > 0) {
                return value
            }
            else {
                return []
            }
        }
        return []
    }
    
    func isHaveDictionayValude(_ key:NSString) -> (NSDictionary) {
        if let value = self[key] as? NSDictionary {
            
                return value
            
        }
        return [String:AnyObject]() as (NSDictionary)
    }
    
  
}

//MARK: - UIImage

extension UIImage {
    func RBSquareImageTo(_ image: UIImage, size: CGSize) -> UIImage? {
        return RBResizeImage(RBSquareImage(image), targetSize: size)
    }
    
    func RBSquareImage(_ image: UIImage) -> UIImage? {
        let originalWidth  = image.size.width
        let originalHeight = image.size.height
        
        var edge: CGFloat
        if originalWidth > originalHeight {
            edge = originalHeight
        } else {
            edge = originalWidth
        }
        
        let posX = (originalWidth  - edge) / 2.0
        let posY = (originalHeight - edge) / 2.0
        
        let cropSquare = CGRect(x: posX, y: posY, width: edge, height: edge)
        
        let imageRef = image.cgImage?.cropping(to: cropSquare);
        return UIImage(cgImage: imageRef!, scale: UIScreen.main.scale, orientation: image.imageOrientation)
    }
    
    func RBResizeImage(_ image: UIImage?, targetSize: CGSize) -> UIImage? {
        if let image = image {
            let size = image.size
            
            let widthRatio  = targetSize.width  / image.size.width
            let heightRatio = targetSize.height / image.size.height
            
            // Figure out what our orientation is, and use that to form the rectangle
            var newSize: CGSize
            if(widthRatio > heightRatio) {
                newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
            } else {
                newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
            }
            
            // This is the rect that we've calculated out and this is what is actually used below
            let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
            
            // Actually do the resizing to the rect using the ImageContext stuff
           // UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
            UIGraphicsBeginImageContextWithOptions(newSize, false, UIScreen.main.scale)
            image.draw(in: rect)
            let newImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            return newImage
        } else {
            return nil
        }
    }
    
    func reduceImageSize(_ image:UIImage) -> UIImage {
        
        
        var actualHeight:CGFloat = image.size.height
        var actualWidth:CGFloat = image.size.width
        var imgRatio:CGFloat = actualWidth/actualHeight
        let maxRatio:CGFloat = 320.0/480.0;//
      ///  let maxRatio:CGFloat = 414.0/736.0
        
        if imgRatio != maxRatio {
            if imgRatio < maxRatio {
                imgRatio = 480.0 / actualHeight
             //   imgRatio = 736.0/actualHeight
                actualWidth = imgRatio * actualWidth
                 actualHeight = 480.0;
               // actualHeight = 736.0
            }
            else {
                 imgRatio = 320.0 / actualWidth;
               // imgRatio = 414.0 / actualWidth
                actualHeight = imgRatio * actualHeight
                actualWidth = 414.0
            }
        }
        
        let rect:CGRect = CGRect(x: 0.0, y: 0.0, width: actualWidth, height: actualHeight)
        UIGraphicsBeginImageContext(rect.size)
        image .draw(in: rect)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return img!
    }
    
    func adjustImageSizeWhenCropping(_ image:UIImage) -> UIImage {
        
        var actualHeight:CGFloat = image.size.height
        let actualWidth:CGFloat = image.size.width
//        var imgRatio:CGFloat = actualWidth/actualHeight
//        let maxRatio:CGFloat = 414.0/736.0
        let screenRect = UIScreen.main.bounds
        let screenWidth = screenRect.size.width
        let rect:CGRect!
        
        if(actualWidth > screenWidth) {
            let ratio = screenWidth/actualWidth
            actualHeight = actualHeight * ratio
            rect = CGRect(x: 0.0, y: 0.0, width: screenWidth, height: actualHeight)
        }
        else {
            rect = CGRect(x: 0.0, y: 0.0, width: actualWidth, height: actualHeight)
        }
        
       
        UIGraphicsBeginImageContextWithOptions(rect.size, false, 1.0)
        image .draw(in: rect)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return img!
    }
    
    func resizeImageWithImage(_ image:UIImage,newSize:CGSize) -> UIImage {
        var ratio:CGFloat!
        var delta:CGFloat!
        var offset:CGPoint!
        
        //make a new square size, that is the resized imaged width
        let sz:CGSize = CGSize(width: newSize.width, height: newSize.height)
        
        //figure out if the picture is landscape or portrait, then
        //calculate scale factor and offset
        if image.size.width > image.size.height {
            ratio = newSize.width/image.size.width
            delta = (ratio * image.size.width - ratio * image.size.height)
            offset = CGPoint(x: delta/2, y: 0)
        }
        else {
            ratio = newSize.width/image.size.height
            delta = (ratio * image.size.height - ratio * image.size.width)
            offset = CGPoint(x: 0, y: delta/2)
        }
        
        //make the final clipping rect based on the calculated values
        let clipRect = CGRect(x: -offset.x, y: -offset.y, width: (ratio * image.size.width) + delta, height: (ratio * image.size.height) + delta)
        
        //start a new context, with scale factor 0.0 so retina displays get
        //high quality image

        if UIScreen.main .responds(to: "scale") {
            UIGraphicsBeginImageContextWithOptions(sz, true, 0.0)
            
        }else {
            UIGraphicsBeginImageContext(sz)
        }
        
        UIRectClip(clipRect)
        image .draw(in: clipRect)
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        return newImage
        
    }
  

}

// MARK: - TextField

extension UITextField {
    
    func setTextFieldPadding () {
        
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: self.frame.height))
        self.leftView = paddingView
        self.leftViewMode = UITextField.ViewMode.always
    }
}
extension UIDevice {
    
    var modelName: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        switch identifier {
        case "iPod5,1":                                 return "iPod Touch 5"
        case "iPod7,1":                                 return "iPod Touch 6"
        case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
        case "iPhone4,1":                               return "iPhone 4s"
        case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
        case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
        case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
        case "iPhone7,2":                               return "iPhone 6"
        case "iPhone7,1":                               return "iPhone 6 Plus"
        case "iPhone8,1":                               return "iPhone 6s"
        case "iPhone8,2":                               return "iPhone 6s Plus"
        case "iPhone9,1", "iPhone9,3":                  return "iPhone 7"
        case "iPhone9,2", "iPhone9,4":                  return "iPhone 7 Plus"
        case "iPhone8,4":                               return "iPhone SE"
        case "iPhone10,1", "iPhone10,4":                return "iPhone 8"
        case "iPhone10,2", "iPhone10,5":                return "iPhone 8 Plus"
        case "iPhone10,3", "iPhone10,6":                return "iPhone X"
        case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
        case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
        case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
        case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
        case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
        case "iPad6,11", "iPad6,12":                    return "iPad 5"
        case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
        case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
        case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
        case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
        case "iPad6,3", "iPad6,4":                      return "iPad Pro 9.7 Inch"
        case "iPad6,7", "iPad6,8":                      return "iPad Pro 12.9 Inch"
        case "iPad7,1", "iPad7,2":                      return "iPad Pro 12.9 Inch 2. Generation"
        case "iPad7,3", "iPad7,4":                      return "iPad Pro 10.5 Inch"
        case "AppleTV5,3":                              return "Apple TV"
        case "AppleTV6,2":                              return "Apple TV 4K"
        case "AudioAccessory1,1":                       return "HomePod"
        case "i386", "x86_64":                          return "Simulator"
        default:                                        return identifier
        }
    }
    
}

/*
extension UIColor {
    convenience init(rgb: UInt) {
        self.init(
            red: CGFloat((rgb & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgb & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgb & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
} */
