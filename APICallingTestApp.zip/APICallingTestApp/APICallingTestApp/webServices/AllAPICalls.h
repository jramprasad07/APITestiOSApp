//
//  AllAPICalls.h
//  APICallingTestApp
//
//  Created by iMac2 on 02/02/23.
//

#ifndef AllAPICalls_h
#define AllAPICalls_h


#define GetCustomerInfo @"api/CustomerInfoApi/GetCustomerInfo?"
#define isExistTrackingId @"api/shipmentsAPi/isExistTrackingId?"
#define Countries @"api/RegistrationAPI/Countries?"



#endif /* AllAPICalls_h */
