//
//  LoadingOverlay.swift
//  APICallingTestApp
//
//  Created by iMac2 on 02/02/23.
//

import UIKit
import Foundation

open class LoadingOverlay{
    var isLoading:Bool = false
    var overlayView = UIView()
    let overlayBGView = UIView()
    var activityIndicator = UIActivityIndicatorView()
    
    class var shared: LoadingOverlay {
        struct Static {
            static let instance: LoadingOverlay = LoadingOverlay()
        }
        return Static.instance
    }

    
    open func showOverlay(_ view: UIView) {
        isLoading = true
        
        overlayBGView.frame = view.frame
        overlayBGView.backgroundColor = UIColor.clear
        
        overlayView.frame = CGRect.init(x: 0, y: 0, width: 80, height: 80)
        overlayView.center = view.center
        overlayView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5)
        overlayView.clipsToBounds = true
        overlayView.layer.cornerRadius = 10
        
        activityIndicator.frame = CGRect.init(x: 0, y: 0, width: 40, height: 40)
        activityIndicator.color = UIColor.red
        activityIndicator.style = .whiteLarge
         activityIndicator.color = UIColor.white
        activityIndicator.center = CGPoint.init(x: overlayView.bounds.width / 2, y: overlayView.bounds.height / 2)
            //CGPointMake(overlayView.bounds.width / 2, overlayView.bounds.height / 2)
        
        overlayView.addSubview(activityIndicator)
        overlayBGView.addSubview(overlayView)
        view.addSubview(overlayBGView)
        
        activityIndicator.startAnimating()
    }
    
    open func hideOverlayView() {
        isLoading = false
        activityIndicator.stopAnimating()
        overlayBGView.removeFromSuperview()
    }
}

