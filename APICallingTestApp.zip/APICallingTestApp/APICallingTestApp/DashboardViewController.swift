//
//  DashboardViewController.swift
//  APICallingTestApp
//
//  Created by iMac2 on 14/04/23.
//

import UIKit

class DashboardViewController: UIViewController {

    
    @IBOutlet weak var backBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
//        self.hideKeyboardWhenTappedAround()
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationController?.navigationBar.isHidden = true

        
    }
    
    @IBAction func BackBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    
    

}
