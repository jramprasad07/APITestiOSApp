//
//  ViewController.swift
//  APICallingTestApp
//
//  Created by iMac2 on 02/02/23.
//

import UIKit
import DropDown

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var getResBtn: UIButton!
    @IBOutlet weak var goToDashboardBtn: UIButton!
    @IBOutlet weak var getUserLocationBtn: UIButton!
    @IBOutlet weak var dropDownBtn: UIButton!
    @IBOutlet weak var ddBGView: UIView!
    @IBOutlet weak var ddSearchTF: UITextField!
    @IBOutlet weak var filterTV: UITableView!
    
    
    var personalInformationArray:NSDictionary!
    var phoneStr = String()
    
    var sCountriesMainDict = NSArray()
    var sCountryNameDictArry:NSArray!
    var sCountryIDDictArry:NSArray!
    var sCountryIDStr:String!
    
    let countryDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {return [self.countryDropDown]}()
    
    var finalArray: NSMutableArray = []
    var arrayFilter:NSMutableArray = []
    var isSearch : Bool = false
    var totalValuesArray:NSMutableArray = []
    var preAlertDataIndexPathRow:NSDictionary!
        
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.hideKeyboardWhenTappedAround()
        
        self.filterTV.isHidden = true
        
        self.getResBtn.layer.cornerRadius = 8
        self.getResBtn.clipsToBounds = true
        
        self.goToDashboardBtn.layer.cornerRadius = 8
        self.goToDashboardBtn.clipsToBounds = true
        self.getUserLocationBtn.layer.cornerRadius = 8
        self.getUserLocationBtn.clipsToBounds = true
        
        self.ddBGView.layer.cornerRadius = 6
        self.ddBGView.layer.borderWidth = 0.8
        self.ddBGView.layer.borderColor = UIColor.systemGray2.cgColor
        
        ddSearchTF.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)), for: .editingChanged)
        
        GetCountriesAPICalling()
        
        
    }

    @IBAction func GetResponseBtnAction(_ sender: Any) {
        GetPersonalInformationAPICalling()
    }
    
    @IBAction func GoToDahsboardBtnAction(_ sender: Any) {
        let dashVC = self.storyboard?.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
        self.navigationController?.pushViewController(dashVC, animated: true)
    }
    
    @IBAction func GetUserLocationBtnAction(_ sender: Any) {
        let userLocVC = self.storyboard?.instantiateViewController(withIdentifier: "GetUserLocationViewController") as! GetUserLocationViewController
        self.navigationController?.pushViewController(userLocVC, animated: true)
    }
    
    @IBAction func GetStringResponseBtnAction(_ sender: Any) {
        GetStringResponseAPICalling()
    }
    
    @IBAction func DropDownBtnAction(_ sender: Any) {
        self.view.endEditing(true)
        setupSourceCountriesDropDown()
    }
    
    func GetPersonalInformationAPICalling() {
        
        let webAPI = WebServiceHandler()
        if LoadingOverlay.shared.isLoading == false {
            LoadingOverlay.shared.showOverlay(self.view)
        }
        let parameters: [String: String]
        parameters = ["Custid":"ICID-1341","Activationkey": "123456789","CompanyID":"130"]
        print(parameters)
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
            let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
            print("check json pritty <======\(jsonString)")
        } catch {
            print(error.localizedDescription)
        }
        webAPI.sendRequestToApi3(apiName: GetCustomerInfo as NSString?, parms: parameters as AnyObject, completion: {(result) -> Void in
            if result is NSDictionary {
                
                if LoadingOverlay.shared.isLoading == true {
                    LoadingOverlay.shared.hideOverlayView()
                }
                print("result => ", result)
                
                self.GetPersonalDataAPIHandler(dictItems: result as! NSDictionary)
            }
        }, failure: { (err) -> Void in
            print(err)
        })
        
    }
    
    func GetPersonalDataAPIHandler(dictItems: NSDictionary) {
        
        print("Personal Details : \(dictItems)")
        let statusCheck = dictItems["Response"] as? String
        if statusCheck == "1" {
            
            if dictItems["Data"] as? NSDictionary != nil{
                personalInformationArray = dictItems["Data"] as? NSDictionary
                print("additionalAddressArray  \(personalInformationArray!)")
                self.phoneStr = personalInformationArray.value(forKey: "PrimaryNumber") as? String ?? ""
                print("1= PHONE NUMBER - self.phoneStr  \(self.phoneStr)")
                
                let alert = UIAlertController(title: "SUCCESS", message: "Your API calling success. Number is: \(self.phoneStr)", preferredStyle: .alert)
                let actionYes = UIAlertAction(title: "Ok", style: .default) { action in
                    
                }
                alert.addAction(actionYes)
                present(alert, animated: true, completion: nil)
                
            } else {
                //              Helper.sharedInstance.makeAlertCall(msg: "No data found" as NSString)
            }
            
        } else{
            let Desc = dictItems["Description"] as? String ?? "No data found"
            Helper.sharedInstance.makeAlertCall(msg: Desc as NSString)
        }
    }
    
    func GetStringResponseAPICalling() {
        
        let webAPI = WebServiceHandler()
        if LoadingOverlay.shared.isLoading == false {
            LoadingOverlay.shared.showOverlay(self.view)
        }
        let parameters: [String: String]
        parameters = ["TrackingId":"0982222","CompanyID":"130"]
        print(parameters)
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
            let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
            print("check json pritty <======\(jsonString)")
        } catch {
            print(error.localizedDescription)
        }
        webAPI.sendRequestToApi3StringResponse(apiName: isExistTrackingId as NSString?, parms: parameters as AnyObject, completion: {(result) -> Void in
            if result is String {
                
                if LoadingOverlay.shared.isLoading == true {
                    LoadingOverlay.shared.hideOverlayView()
                }
                print("result => ", result)
                
                self.GetStringResponseAPIHandler(dictItems: result as! String)
            }
        }, failure: { (err) -> Void in
            print(err)
        })
        
    }
    
    func GetStringResponseAPIHandler(dictItems: String) {
        
        print("Personal Details : \(dictItems)")
        
        self.showToast(message: "\(dictItems)")
        
        print("Personal Details : 124455")
        
       
    }
    
    func GetCountriesAPICalling() {
        
        let webAPI = WebServiceHandler()
        if LoadingOverlay.shared.isLoading == false {
            LoadingOverlay.shared.showOverlay(self.view)
        }
        let parameters: [String: String]
        parameters = ["ActivationKey": "123456789","CompanyID":"130"]
        print(parameters)
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
            let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
            print("check json pritty <======\(jsonString)")
        } catch {
            print(error.localizedDescription)
        }
        webAPI.sendRequestToApi3(apiName: Countries as NSString?, parms: parameters as AnyObject, completion: {(result) -> Void in
            if result is NSDictionary {
                
                if LoadingOverlay.shared.isLoading == true {
                    LoadingOverlay.shared.hideOverlayView()
                }
                print("result => ", result)
                
                self.GetCountriesAPIHandler(dictItems: result as! NSDictionary)
            }
        }, failure: { (err) -> Void in
            print(err)
        })
        
    }
    
    func GetCountriesAPIHandler(dictItems: NSDictionary) {
        
        print("Personal Details : \(dictItems)")
        let statusCheck = dictItems["ResCode"] as? Int
        if statusCheck == 1 {
            
            let data = dictItems["Data"]
            sCountriesMainDict = (data as? NSArray)!
            
            for items in sCountriesMainDict {
                let itemObj = NSMutableDictionary()
                
                itemObj.setValue((items as AnyObject).value(forKey: "CountryCode") as? String, forKey: "CountryCode")
                itemObj.setValue((items as AnyObject).value(forKey: "CountryDesc") as? String, forKey: "CountryDesc")
          
                finalArray.add(itemObj)
                
            }
            print("Countries count : \(finalArray.count)")
    
        } else{
            let Desc = dictItems["Msg"] as? String ?? "No data found"
            Helper.sharedInstance.makeAlertCall(msg: Desc as NSString)
        }
    }
    
    func setupSourceCountriesDropDown() {
        
        countryDropDown.anchorView = dropDownBtn
        countryDropDown.width = view.frame.size.width - 50
        dropDowns.forEach { $0.direction = .bottom }
        countryDropDown.frame.size.height = 50
        countryDropDown.bottomOffset = CGPoint(x: 0, y: dropDownBtn.bounds.height)
        print("countriesDict is \(sCountriesMainDict)")
        sCountryNameDictArry = (sCountriesMainDict.value(forKey: "CountryDesc") as? NSArray)!
        print("countryName is \(sCountryNameDictArry!)")
        
        countryDropDown.dataSource = sCountryNameDictArry as! [String]
        countryDropDown.show()
        countryDropDown.selectionAction = { [unowned self] (index, item) in
            print(("Selected index \(item)"))
       //     self.dropDownBtn.setTitle(item, for: .normal)
            self.ddSearchTF.text = item
            sCountryIDDictArry = (self.sCountriesMainDict.value(forKey: "CountryCode") as? NSArray)!
            
            print("cIdArray is \(sCountryIDDictArry!)")
            self.sCountryIDStr = sCountryIDDictArry.object(at: index) as? String
            print("selected country id is \(self.sCountryIDStr!)")
        }
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        
        var name: NSArray
        
        name = sCountriesMainDict.filter({ (Master) -> Bool in
            var ns:NSDictionary!
            ns = Master as? NSDictionary
            
            let tmp: NSString = (ns.value(forKey: "CountryDesc") as? NSString)!
            print("tmp \(tmp)")
            
            let aat = self.ddSearchTF.text!
            let range = tmp.range(of: aat, options: NSString.CompareOptions.caseInsensitive)
            return range.location != NSNotFound
        }) as NSArray
        if(name.count == 0){
            isSearch = false
            filterTV.isHidden = true
            
        } else {
            isSearch = true
            filterTV.isHidden = false
            
            self.filterTV.dataSource = self
            self.filterTV.delegate = self
            self.filterTV.reloadData()
            
        }
        print("Filter Array \(name) and length \(name.count)")
        arrayFilter = NSMutableArray(array:name)
        print("Filter Array \(arrayFilter) and length \(arrayFilter.count)")
        self.filterTV.reloadData()


    }
    
    //MARK: - tableview delegate methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if arrayFilter.count > 0{
            return arrayFilter.count
        }
        return finalArray.count
    }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell( withIdentifier: "CountryTableViewCell", for: indexPath)as! CountryTableViewCell
        let tblcolor = UIColor(red: 190.0/255.0, green: 188.0/255.0, blue: 187.0/255.0, alpha: 1.0)
        cell.layer.borderWidth = 0.5
        cell.layer.borderColor = tblcolor.cgColor
        
        if arrayFilter.count > 0 {
            totalValuesArray = arrayFilter
        } else if finalArray.count > 0{
            totalValuesArray = finalArray
        }
        print(totalValuesArray as Any)
        
        self.preAlertDataIndexPathRow = totalValuesArray[indexPath.row] as? NSDictionary
        print("totalValuesArray \(totalValuesArray)")
        
        cell.countryNameLbl.text = (totalValuesArray[indexPath.row] as AnyObject).value(forKey: "CountryDesc") as? String
        
        cell.sizeToFit()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.view.endEditing(true)
        self.ddSearchTF.text = (totalValuesArray[indexPath.row] as AnyObject).value(forKey: "CountryDesc") as? String
        self.filterTV.isHidden = true
    }
  
    
}

extension UIViewController {
    
    func showToast(message : String) {
        
        let toastLabel = UILabel(frame: CGRect(x: 40, y: self.view.frame.size.height-200, width: self.view.frame.size.width - 80, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }
    
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
